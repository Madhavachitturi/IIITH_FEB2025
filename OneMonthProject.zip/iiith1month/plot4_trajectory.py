import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

file_path = "/home/madhava/iiith1month/log_0_2025-2-17-09-29-46_vehicle_local_position_0.csv"
df = pd.read_csv(file_path)

time = df["timestamp"]
x = df["x"]
y = df["y"]
z = df["z"]

gps_status = df["eph"]  
# if eph is  high it means bad GPS
gps_failure_index = gps_status[gps_status > 10].index[0]  
# Splitting trajectory of drone before and after GPS failure
x_before, y_before, z_before = x[:gps_failure_index], y[:gps_failure_index], z[:gps_failure_index]
x_after, y_after, z_after = x[gps_failure_index:], y[gps_failure_index:], z[gps_failure_index:]

fig = plt.figure()
ax = fig.add_subplot(111, projection="3d")
ax.plot(x_before, y_before, z_before, label="Before GPS Failure", color="blue")
ax.plot(x_after, y_after, z_after, label="After GPS Failure", color="red")

ax.set_xlabel("X Position (m)")
ax.set_ylabel("Y Position (m)")
ax.set_zlabel("Z Position (m)")
ax.set_title("Quadrotor Trajectory Before & After GPS Failure")
ax.legend()
plt.show()