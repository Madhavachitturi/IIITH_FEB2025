import pandas as pd
import matplotlib.pyplot as plt

file_path = "/home/madhava/Desktop/logfiles/finallog/log_7_2025-3-6-10-12-41_vehicle_status_0.csv"  
df_vehicle_status = pd.read_csv(file_path)
# /1e6 is used to plot the graph in seconds instead of microseconds
df_vehicle_status["timestamp"] = df_vehicle_status["timestamp"] / 1e6  

plt.figure(figsize=(10, 5))
plt.plot(df_vehicle_status["timestamp"], df_vehicle_status["nav_state"], marker='o', linestyle='-', color='b', label="Navigation State")

plt.axhline(y=4, color='r', linestyle='--', label="auto_land (Failsafe mode)")
plt.xlabel("Time (seconds)")
plt.ylabel("Navigation State")
plt.title("Time Series Plot of Failsafe Activation (nav_state)")
plt.legend()
plt.grid()
plt.show()