import pandas as pd
import matplotlib.pyplot as plt

vel_data = pd.read_csv('/home/madhava/iiith1month/log_0_2025-2-17-09-29-46_vehicle_local_position_0.csv')
vel_data['time_s'] = vel_data['timestamp'] * 1e-6 # Convert timestamp to seconds

status_data = pd.read_csv('/home/madhava/iiith1month/log_0_2025-2-17-09-29-46_vehicle_status_0.csv')
status_data['time_s'] = status_data['timestamp'] * 1e-6

failsafe_event = status_data[status_data['failsafe'] == 1]  
failsafe_time = failsafe_event['time_s'].iloc[0] if not failsafe_event.empty else None
plt.figure(figsize=(10, 5))
plt.plot(vel_data['time_s'], vel_data['vx'], label='Vx (m/s)', color='r')
plt.plot(vel_data['time_s'], vel_data['vy'], label='Vy (m/s)', color='g')
plt.plot(vel_data['time_s'], vel_data['vz'], label='Vz (m/s)', color='b')

if failsafe_time:
    plt.axvline(x=failsafe_time, color='k', linestyle='--', label='Failsafe Triggered')
plt.xlabel('Time (s)')
plt.ylabel('Velocity (m/s)')
plt.legend()
plt.title('Drone Velocity During GPS Failsafe')
plt.grid()
plt.show()

