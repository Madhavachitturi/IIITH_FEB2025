import pandas as pd
import matplotlib.pyplot as plt

file_path = "/home/madhava/iiith1month/log_0_2025-2-17-09-29-46_vehicle_local_position_0.csv"  
df = pd.read_csv(file_path)
plt.figure(figsize=(10, 5))

df["timestamp"] = df["timestamp"] / 1e6  # Converting from microseconds to seconds
plt.plot(df["timestamp"], df["x"], label="X Position")
plt.plot(df["timestamp"], df["y"], label="Y Position")
plt.plot(df["timestamp"], df["z"], label="Z Position")

plt.xlabel("Time (seconds)")
plt.ylabel("Position (meters)")
plt.title("Quadrotor Position Over Time")
plt.legend()
plt.grid()
plt.show()